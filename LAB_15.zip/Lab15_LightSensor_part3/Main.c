
#include "ADC.h"
#include "UART.h"
#include "Init.h"
#include "tm4c123gh6pm.h"

#define FALSE 0
#define TRUE  1

#define BUS_FREQ 80      		  // [MHz] bus clock
#define PWM_FREQ 4000      		// [Hz] bus clock
#define NORMALIZER 1000000	  // [1M] divider clock

#define SUPPLY_VOLTAGE 3300   // [mV]
//find maximum value of ADC
#define ADC_MAX  4095         // 12-bit number
//find maximum volatage in mV
#define MAX_VOLT   3300  		  // [mV]  maximum expected voltage: 100%
//find minimum voltage in mV
#define MIN_VOLT   0.805  		// [mV]  minimum expected voltage: 0%
//maximum value for duty cycle in PWM mode
#define MAX_DUTY 1000


void EnableInterrupts(void);      // Enable interrupts

unsigned long ADCdata = 0;        // 12-bit 0 to 4095 sample
unsigned long Flag = FALSE;       // The ADCdata is ready

unsigned long Signal_High = 0;    // Signal_High of PWM
unsigned long Signal_Low = 0;	  // Signal_Low of PWM
unsigned long counter = 0;		  // counter for duty cycle

double resolution = 0.805;      // floating point number, resolution
unsigned long adcCount = 0;	 	  // ADC sampling counter

//********Convert2Voltage****************
// Convert a 12-bit binary ADC sample into a 32-bit unsigned
// fixed-point voltage (resolution 1 mV).  
// Maximum and minimum values are calculated 
// and are dependant on resitor value.
// Overflow and dropout should be considered 
// Input: sample  12-bit ADC sample
// Output: 32-bit voltage (resolution 1 mV)
unsigned long Convert2Voltage(unsigned long sample)
{
	unsigned long voltage=0;
//your code should be here
//converts Digital Data to Voltage. 
	sample = (unsigned long)(sample*resolution);
	voltage = sample + MIN_VOLT;
	return voltage;
}


//********CropOffVoltageADC****************
// Regularize voltage reading by removing the extremes
// Input: voltage (mV)
// Output: cropped voltage (mV)
unsigned long CropOffVoltageADC (unsigned long voltage)
{
	unsigned long pct_cropped = 0;	
	pct_cropped = (voltage - MIN_VOLT) * MAX_DUTY / (MAX_VOLT - MIN_VOLT);
	return pct_cropped;
}

//********ConversionCycle_Duty****************
// Convert voltage reading into fixed-point precision
// luminosity percentage (resolution 0.1%). 
// Assume non-linear dependency.
// Input: voltage (mV)
// Output: fixed-point percent ((resolution 0.1%)
unsigned long ConversionCycle_Duty (unsigned long pct_cropped)
{
	unsigned long duty_sweep = 0;
	// D = pct_cropped * pct_cropped * pct_cropped / divider;
	duty_sweep = pct_cropped * pct_cropped * pct_cropped / NORMALIZER;
	//duty_sweep = MAX_DUTY - duty_sweep;  // Task 3.1.(2)
	return duty_sweep;
}

// Initialize SysTick with interrupts 
void SysTick_Init(unsigned long SysTick_Reload_Value)
{
	NVIC_ST_CTRL_R = 0;              // 1) disable SysTick during setup
	NVIC_ST_RELOAD_R = SysTick_Reload_Value;       // reload value
	NVIC_ST_CURRENT_R = 0;           // 3) any write to current clears it
	NVIC_SYS_PRI3_R = NVIC_SYS_PRI3_R&0x00FFFFFF; // priority 0
	NVIC_ST_CTRL_R = 0x00000007;     // 4) enable SysTick with core clock with interrupts
}

//********SysTick_Handler****************
// Fires whenever reload value reaches 0.
// ISR for PA2 ==> PWM Handler and PE2 ==> ADC Handler
void SysTick_Handler(void)
{	
	if(adcCount==0) { // ADC sampling counter has recently reached 100
		Flag = TRUE;          // ADCdata is ready
		ADCdata = ADC0_In();  // Call ADC function
	}
	
  if(GPIO_PORTA_DATA_R&0x04)
		{   // checking if PA2 is High
			GPIO_PORTA_DATA_R &= ~0x04;           // make PA2 low
			NVIC_ST_RELOAD_R = Signal_High-1;     // count down to next Signal_High
			adcCount++;
		} 	
		else
			{ // if PA2 is Low
				GPIO_PORTA_DATA_R |= 0x04;           // make PA2 High
				NVIC_ST_RELOAD_R = Signal_Low-1;     // count down to next Signal_Low
				if(adcCount==100) { // The limit of 100 times PWM signaling has been reached
					adcCount=0; // Reset adcCount
				}
			}	
}

//***************Delay*******************
// Fires a delay cycle.
// Input: number of delay cycles where 1 cycle == 800 Hz
// Output: none
void Delay (unsigned long delay_Cycles)
{	
	unsigned long volatile i = (delay_Cycles * 100000) - 1;
	while(i>0){i--;}
}

//*******FindInitialReloadValue*************
// Calculates the PWM reload value based on the PWM period.
// Input: none
// Output: reload value in terms of ticks
unsigned long FindInitialReloadValue(void)
{
	unsigned long InitialReloadValue = 0;
//  PWM Reload value calculating
	InitialReloadValue = (BUS_FREQ * NORMALIZER) / PWM_FREQ; 
return InitialReloadValue - 1;
}

//*******ReloadValueConverted*************
// Converts duty cycle % to portion of PWM reload value
// Input: duty cycle in percentage and PWM reload value
// Output: reload value of on-time in terms of ticks
unsigned long ReloadValueConverted(unsigned long duty_sweep, unsigned long SysTick_Reload_Value)
{
	unsigned long New_ReloadValue = 0;
// duty_sweep is the value from of 0 - 1000; therefore the divider = 1000
	New_ReloadValue = duty_sweep * SysTick_Reload_Value / MAX_DUTY; 
return New_ReloadValue;
}

// a simple main program allowing you to debug the ADC & PWM interfaces
int main(void){ 
	unsigned long SysTick_Reload_Value = 0;
	unsigned long voltage = 0; 
	unsigned long PercentageofVoltage = 0;
	unsigned long duty_sweep = 0;
	
	PLL_Init();
	ADC0_Init(); // initialize ADC0 for PE2, channel 1, sequencer 3
	UART_Init();
	//write initialization for PA2 for PWM
	PWM_Init();
	SysTick_Reload_Value = FindInitialReloadValue();
	//write initialization for SysTick 
	SysTick_Init(SysTick_Reload_Value);								
  EnableInterrupts();
	
	while(TRUE) {			
		while(Flag) { // if the ADC reading flag is true
			voltage = Convert2Voltage(ADCdata);		              // Take raw ADCdata and convert it to voltage
			PercentageofVoltage = CropOffVoltageADC(voltage);   // calculate the percentage of voltage
			//Delay(2);
			
// Non-linearity function application
			duty_sweep = ConversionCycle_Duty(PercentageofVoltage); 
			Signal_High = ReloadValueConverted(duty_sweep, SysTick_Reload_Value); 
			Signal_Low = SysTick_Reload_Value - Signal_High;	

// Now here the output is being converted to string to show on USB interface via UART 
			UART_OutRaw(ADCdata);
			UART_OutVoltage(voltage);		
			UART_OutPercent(duty_sweep);		
			// Delay for 40Hz	
			//Delay(20);
			// Flipping flag
			Flag = !Flag; // Reset the ADC reading flag after necessary operations are completed
			}
	}
}

